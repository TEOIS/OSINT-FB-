<?php
 /**
 * @category  Social_Engineering
 * @package  OSINT-FB
 * @author    BILAL ALI <anynomouscheetah@gmail.com>
 * @copyright 2022
 * @version   1.0
 * @link      https://github.com/TEOIS/OSINT-FB
 */

$n = 1;
function getName($n)
{
    $characters = '123456789';
    $randomString = '';

    for ($i = 0; $i < $n; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $randomString .= $characters[$index];
    }

    return $randomString;
}
