<?php
 /**
 * @category  Social_Engineering
 * @package  OSINT-FB
 * @author    BILAL ALI <anynomouscheetah@gmail.com>
 * @copyright 2022
 * @version   1.0
 * @link      https://github.com/TEOIS/OSINT-FB
 */

$progress = $climate->progress()->total(100);

function progress($progress)
{
    for ($i = 0; $i <= 100; $i++) {
        $progress->current($i);
        usleep(30000);
    }
}
