<?php
 /**
 * @category  Social_Engineering
 * @package  OSINT-FB
 * @author    BILAL ALI <anynomouscheetah@gmail.com>
 * @copyright 2022
 * @version   1.0
 * @link      https://github.com/TEOIS/OSINT-FB
 */

error_reporting(0);

$input = $climate->br()->input('Username or ID?');
$id = $input->prompt();

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url_based . "/" . $id . "?access_token=" . $token);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$wahyuarifpurnomo = curl_exec($curl);
curl_close($curl);

$decode = json_decode($wahyuarifpurnomo);
$location = $decode->location->name;
$colorstring = getName($n);
echo $colors->getColoredString("> Name : $decode->name \n> Email : $decode->email \n> Phone : $decode->mobile_phone \n> ID : $decode->id \n> Location : $location \n> Bio : $decode->bio \n> Birthday : $decode->birthday \n> Gender : $decode->gender \n> Website : $decode->website \n> Link Profile : $decode->link \n> Religion : $decode->religion \n> Status : $decode->relationship_status \n", $warifp[$colorstring]) . "\n";
